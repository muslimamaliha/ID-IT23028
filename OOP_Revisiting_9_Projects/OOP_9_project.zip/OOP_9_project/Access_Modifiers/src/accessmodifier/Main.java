package accessmodifier;

public class Main {
    public static void main(String[] args) {
        Person p = new Person();
        p.setName("Maliha");
        System.out.println(p.getName());
    }
}