package accessmodifier;
class Person {
    private String name;

    public void setName(String newName)
    {
        name = newName;
    }

    public String getName() {
        return name;
    }
}