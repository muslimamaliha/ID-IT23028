package classandobject;
class Car {
    String color;
    int speed;

    void drive()
    {
        System.out.println("Car is driven....");

    }

}
