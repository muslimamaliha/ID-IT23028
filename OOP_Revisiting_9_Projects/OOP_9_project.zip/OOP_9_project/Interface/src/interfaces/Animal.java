package interfaces;

public interface Animal {
    void sound();
}
