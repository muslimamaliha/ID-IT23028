package abstractclasses;

public class Dog extends Animal{
    void makeSound() {
        System.out.println("Barking!");
    }
}
