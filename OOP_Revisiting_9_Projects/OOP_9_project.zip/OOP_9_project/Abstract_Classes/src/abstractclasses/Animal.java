package abstractclasses;

abstract class Animal {
    abstract void makeSound();

    void sleep() {
        System.out.println("Sleeping....");
    }
}
