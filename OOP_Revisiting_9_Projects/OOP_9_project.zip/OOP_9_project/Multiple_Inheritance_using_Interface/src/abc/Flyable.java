package abc;

interface Flyable {
    void fly();
}
