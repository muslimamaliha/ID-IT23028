package abc;

interface Swimmable {
    void swim();
}
