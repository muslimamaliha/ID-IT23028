package inheritance;

public class Animal {
    protected String type = "Animal";

    void display(){
        System.out.println("This is an animal.");
    }
}
